import React, { useState, useRef, useEffect, useCallback } from 'react';

// ==========================================
// 1. ICONS
// ==========================================
const Icons = {
  Sun: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>,
  Moon: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>,
  Upload: () => <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>,
  Close: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
  Back: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>,
  Camera: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>,
  Folder: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>,
  Check: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>,
  Warning: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
};

// ==========================================
// 2. CONSTANTS
// ==========================================
const LANGUAGES = [
  { code: 'ru', label: 'Русский', flag: '🇷🇺' },
  { code: 'en', label: 'English', flag: '🇺🇸' },
  { code: 'old', label: 'Старослав.', flag: '📜' },
  { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
];

const FILTERS = [
  { id: 'none', label: 'Оригинал' },
  { id: 'grayscale', label: 'Ч/Б', style: { filter: 'grayscale(100%)' } },
  { id: 'sepia', label: 'Сепия', style: { filter: 'sepia(100%)' } },
  { id: 'contrast', label: 'Контраст', style: { filter: 'contrast(150%)' } },
];

// ==========================================
// 3. HOOKS
// ==========================================

const useCamera = (onCapture, onError) => {
  const videoRef = useRef(null);
  const [mediaStream, setMediaStream] = useState(null);
  const [isActive, setIsActive] = useState(false);
  const [isCameraLoading, setIsCameraLoading] = useState(false);

  const stop = useCallback(() => {
    if (mediaStream) {
      mediaStream.getTracks().forEach(track => { track.stop(); track.enabled = false; });
      setMediaStream(null);
    }
    setIsActive(false);
    setIsCameraLoading(false);
  }, [mediaStream]);

  const start = useCallback(async () => {
    if (location.protocol !== 'https:' && location.hostname !== 'localhost') {
        onError('Камера работает только по HTTPS!');
        return;
    }
    if (isActive) return;
    setIsCameraLoading(true);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1920 }, height: { ideal: 1080 } }
      });
      setMediaStream(stream);
      setIsActive(true);
      setIsCameraLoading(false);
    } catch (err) {
      console.error(err);
      onError('Ошибка доступа к камере.');
      setIsCameraLoading(false);
      stop();
    }
  }, [isActive, onError, stop]);

  const capture = useCallback(() => {
    if (!videoRef.current || !mediaStream) return;
    const video = videoRef.current;
    if (video.videoWidth === 0) return;

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    
    canvas.toBlob(blob => {
      const file = new File([blob], `photo_${Date.now()}.jpg`, { type: "image/jpeg" });
      onCapture(file);
      stop();
    }, 'image/jpeg', 0.92);
  }, [mediaStream, onCapture, stop]);

  useEffect(() => {
    if (videoRef.current && mediaStream) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.onloadedmetadata = () => {
            videoRef.current.play().catch(e => console.error("Play error:", e));
        };
    }
  }, [mediaStream, isActive]);

  useEffect(() => () => stop(), []); 

  return { videoRef, isActive, isCameraLoading, start, stop, capture };
};

const useSidebarResize = (initialWidth) => {
  const [width, setWidth] = useState(initialWidth);
  const [isResizing, setIsResizing] = useState(false);

  useEffect(() => {
    const handleMove = (e) => {
      if (isResizing) setWidth(Math.min(Math.max(e.clientX, 280), 600));
    };
    const handleUp = () => setIsResizing(false);
    
    if (isResizing) {
      window.addEventListener("mousemove", handleMove);
      window.addEventListener("mouseup", handleUp);
      document.body.classList.add('resizing');
    } else {
      document.body.classList.remove('resizing');
    }
    return () => {
      window.removeEventListener("mousemove", handleMove);
      window.removeEventListener("mouseup", handleUp);
    };
  }, [isResizing]);

  return { width, isResizing, startResize: () => setIsResizing(true) };
};

// ==========================================
// 4. MAIN COMPONENT
// ==========================================

const PhotoUploader = () => {
  const [theme, setTheme] = useState('light');
  const [step, setStep] = useState('upload');
  
  // Data
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [quality, setQuality] = useState(null); // { status: 'good'|'bad'|'warn', text: string }
  
  const [language, setLanguage] = useState('ru');
  const [activeFilter, setActiveFilter] = useState('none');
  const [metaData, setMetaData] = useState({ title: '', author: '', year: '' });
  
  // UI
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [notification, setNotification] = useState(null);
  
  // Mobile Focus
  const [isInputFocused, setIsInputFocused] = useState(false);
  const blurTimeoutRef = useRef(null);
  const fileInputRef = useRef(null);

  const showToast = (type, text) => {
    setNotification({ type, text });
    setTimeout(() => setNotification(null), 3000);
  };

  // --- IMAGE ANALYSIS LOGIC ---
  const analyzeImage = (file, url) => {
    setQuality({ status: 'loading', text: 'Анализ...' });
    
    const img = new Image();
    img.src = url;
    img.onload = () => {
      // 1. Resolution Check
      const width = img.naturalWidth;
      const height = img.naturalHeight;
      const mp = (width * height) / 1000000;
      
      // 2. Brightness Check (Sample 100x100 center)
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 100;
      canvas.height = 100;
      // Draw center crop
      ctx.drawImage(img, width/2 - 50, height/2 - 50, 100, 100, 0, 0, 100, 100);
      
      const imageData = ctx.getImageData(0,0,100,100);
      const data = imageData.data;
      let r,g,b,avg;
      let colorSum = 0;

      for(let x = 0, len = data.length; x < len; x+=4) {
        r = data[x];
        g = data[x+1];
        b = data[x+2];
        avg = Math.floor((r + g + b) / 3);
        colorSum += avg;
      }
      
      const brightness = Math.floor(colorSum / (100*100));

      // Logic
      if (mp < 0.8) {
        setQuality({ status: 'bad', text: 'Низкое разрешение' });
      } else if (brightness < 50) {
        setQuality({ status: 'bad', text: 'Слишком темно' });
      } else if (brightness > 210) {
        setQuality({ status: 'warn', text: 'Засвечено' });
      } else {
        setQuality({ status: 'good', text: 'Отличное качество' });
      }
    };
  };

  const handleFile = (file) => {
    if (file && file.type.startsWith('image/')) {
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
      setStep('upload');
      
      // Run analysis
      analyzeImage(file, url);
      
    } else {
      showToast('error', 'Нужен файл картинки');
    }
  };

  const { videoRef, isActive: isCameraOpen, isCameraLoading, start: startCamera, stop: stopCamera, capture: capturePhoto } = useCamera(
    handleFile, 
    (msg) => showToast('error', msg)
  );
  
  const { width: sidebarWidth, isResizing, startResize } = useSidebarResize(360);

  const handleFirstUpload = () => {
    if (!selectedFile) return;
    // Если качество плохое, можно показать предупреждение, но не блокировать
    if (quality?.status === 'bad') {
        showToast('error', 'Внимание: Качество фото низкое');
    }
    
    setIsLoading(true);
    setTimeout(() => {
      setMetaData({ title: "Скан #1024", author: "OCR System", year: "2024" });
      setIsLoading(false);
      setStep('review');
    }, 1500);
  };

  const handleFinalSubmit = () => {
    setIsLoading(true);
    setTimeout(() => {
      console.log("Final Submit:", metaData);
      setIsLoading(false);
      showToast('success', '✅ Сохранено в базе!');
      setIsInputFocused(false);
    }, 1200);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setMetaData(prev => ({ ...prev, [name]: value }));
  };

  const handleInputFocus = (e) => {
    if (blurTimeoutRef.current) {
        clearTimeout(blurTimeoutRef.current);
        blurTimeoutRef.current = null;
    }
    if (window.innerWidth <= 768) {
      setIsInputFocused(true);
      setTimeout(() => e.target.scrollIntoView({ behavior: 'smooth', block: 'center' }), 300);
    }
  };

  const handleInputBlur = () => {
    blurTimeoutRef.current = setTimeout(() => setIsInputFocused(false), 150);
  };

  const toggleTheme = () => setTheme(t => t === 'light' ? 'dark' : 'light');
  const onDragOver = (e) => { e.preventDefault(); setIsDragging(true); };
  const onDragLeave = (e) => { e.preventDefault(); setIsDragging(false); };
  const onDrop = (e) => { e.preventDefault(); setIsDragging(false); handleFile(e.dataTransfer.files[0]); };

  useEffect(() => {
    const handlePaste = (e) => {
      const items = e.clipboardData.items;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) handleFile(items[i].getAsFile());
      }
    };
    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, []);

  const css = `
    :root {
      --bg: #f4f6f8; --panel: #ffffff; --text: #1a202c; --text-sec: #718096;
      --border: #e2e8f0; --primary: #3182ce; --primary-hover: #2b6cb0;
      --accent: #ebf8ff; --danger: #e53e3e; --success: #38a169; --warn: #d69e2e;
      --input-bg: #f7fafc;
    }
    [data-theme='dark'] {
      --bg: #121212; --panel: #1e1e1e; --text: #ffffff; --text-sec: #a0aec0;
      --border: #333333; --primary: #63b3ed; --primary-hover: #4299e1;
      --accent: #2d3748; --input-bg: #2d3748;
    }
    * { box-sizing: border-box; transition: background 0.3s, color 0.3s, border-color 0.3s; }
    body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Inter", sans-serif; }
    body.resizing { user-select: none; cursor: col-resize; }
    
    .app-layout { display: flex; height: 100dvh; width: 100vw; overflow: hidden; background-color: var(--bg); color: var(--text); flex-direction: row; }
    
    .sidebar { background: var(--panel); border-right: 1px solid var(--border); padding: 30px; display: flex; flex-direction: column; gap: 20px; z-index: 10; overflow-y: auto; position: relative; flex-shrink: 0; }
    .resizer-handle { position: absolute; top: 0; right: 0; width: 5px; height: 100%; cursor: col-resize; z-index: 20; transition: background 0.2s; }
    .resizer-handle:hover, .resizer-handle.active { background: var(--primary); }
    
    .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
    .brand { font-size: 20px; font-weight: 800; }
    .theme-btn { background: transparent; border: 1px solid var(--border); color: var(--text); padding: 8px; border-radius: 50%; cursor: pointer; display: flex; }
    
    .action-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .btn-action {
      display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px;
      padding: 20px; border: 1px dashed var(--border); border-radius: 12px; cursor: pointer;
      color: var(--text-sec); transition: all 0.2s; background: var(--bg);
    }
    .btn-action:hover { border-color: var(--primary); color: var(--primary); background: var(--accent); }
    .btn-action span { font-size: 13px; font-weight: 600; }
    
    .btn { width: 100%; padding: 12px; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; display: flex; justify-content: center; align-items: center; gap: 8px; font-size: 14px; }
    .btn-primary { background: var(--primary); color: #fff; margin-top: auto; }
    .btn-secondary { background: var(--input-bg); color: var(--text); border: 1px solid var(--border); width: auto; align-self: flex-start; }
    
    .main-area { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 30px; position: relative; min-width: 0; }
    
    .preview-box { background: var(--panel); padding: 10px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); display: flex; flex-direction: column; gap: 10px; max-width: 100%; max-height: 90vh; }
    .img-wrap { position: relative; border-radius: 6px; overflow: hidden; max-height: 60vh; }
    .preview-img { display: block; max-width: 100%; max-height: 100%; object-fit: contain; }
    
    /* QUALITY BADGE STYLES */
    .quality-badge {
      position: absolute; bottom: 10px; left: 10px;
      padding: 6px 12px; border-radius: 20px;
      font-size: 12px; font-weight: 600;
      color: white; backdrop-filter: blur(4px);
      display: flex; align-items: center; gap: 6px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    }
    .quality-good { background: rgba(56, 161, 105, 0.9); }
    .quality-warn { background: rgba(214, 158, 46, 0.9); }
    .quality-bad { background: rgba(229, 62, 62, 0.9); }
    
    .camera-container {
      position: relative; border-radius: 16px; overflow: hidden; 
      box-shadow: 0 20px 50px rgba(0,0,0,0.5); background: black;
      width: auto; height: auto; max-width: 100%; max-height: 90vh;
      display: flex; justify-content: center; align-items: center;
    }
    video { max-width: 100%; max-height: 100%; width: auto; height: auto; display: block; }
    .shutter-btn {
      position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%);
      width: 64px; height: 64px; border-radius: 50%; background: white;
      border: 4px solid rgba(0,0,0,0.2); cursor: pointer; transition: transform 0.1s;
      box-shadow: 0 0 20px rgba(0,0,0,0.3);
    }
    .shutter-btn:active { transform: translateX(-50%) scale(0.95); }
    .cam-close { position: absolute; top: 20px; right: 20px; color: white; background: rgba(0,0,0,0.5); padding: 10px; border-radius: 50%; cursor: pointer; backdrop-filter: blur(4px); }
    
    .drop-zone { border: 2px dashed var(--border); border-radius: 12px; width: 100%; max-width: 500px; height: 300px; display: flex; flex-direction: column; align-items: center; justify-content: center; color: var(--text-sec); cursor: pointer; }
    .drop-zone:hover { border-color: var(--primary); background: var(--accent); color: var(--primary); }
    .drop-zone.active { border-color: var(--primary); background: var(--accent); }

    .toast { position: fixed; top: 20px; left: 50%; transform: translateX(-50%); padding: 10px 20px; border-radius: 50px; background: var(--success); color: white; z-index: 100; font-size: 14px; box-shadow: 0 5px 20px rgba(0,0,0,0.15); }
    .toast.error { background: var(--danger); }
    
    .form-group { display: flex; flex-direction: column; gap: 6px; }
    .label { font-size: 11px; font-weight: 700; color: var(--text-sec); text-transform: uppercase; letter-spacing: 0.5px; }
    .input-field { padding: 14px; border-radius: 8px; border: 1px solid var(--border); background: var(--input-bg); color: var(--text); outline: none; width: 100%; font-size: 16px; }
    
    .lang-item { padding: 10px 14px; border-radius: 6px; border: 1px solid var(--border); cursor: pointer; display: flex; align-items: center; justify-content: space-between; color: var(--text); margin-bottom: 6px; }
    .lang-item.active { background: var(--accent); border-color: var(--primary); color: var(--primary); font-weight: 600; }
    .lang-list { display: flex; flex-direction: column; }
    
    .file-card { background: var(--bg); border: 1px solid var(--border); border-radius: 8px; padding: 14px; display: flex; justify-content: space-between; align-items: center; }
    
    .chip { padding: 5px 12px; border-radius: 20px; font-size: 12px; cursor: pointer; background: var(--bg); color: var(--text-sec); white-space: nowrap; border: 1px solid transparent; }
    .chip.active { background: var(--text); color: var(--panel); }
    
    .sheet-handle { display: none; }
    
    @media (max-width: 768px) {
      .app-layout { flex-direction: column-reverse; }
      .resizer-handle { display: none; }
      
      .sidebar { 
        width: 100% !important; border-right: none; border-top: 1px solid var(--border); 
        border-radius: 24px 24px 0 0; padding: 24px; transition: all 0.3s ease;
      }
      .app-layout.step-review .main-area { flex: 0 0 200px; min-height: 200px; padding-bottom: 0; }
      
      .app-layout.input-focused .main-area { display: none; }
      .app-layout.input-focused .sidebar { flex: 1; border-radius: 0; border-top: none; padding-top: 50px; }

      .header { display: none; }
      .sheet-handle { display: block; width: 40px; height: 5px; background: var(--border); border-radius: 3px; margin: 0 auto 24px auto; opacity: 0.6; }
      .mobile-theme-btn { position: absolute; top: 15px; right: 15px; z-index: 50; background: var(--panel); padding: 8px; border-radius: 50%; box-shadow: 0 2px 10px rgba(0,0,0,0.1); color: var(--text); }
      .lang-list { flex-direction: row; overflow-x: auto; padding-bottom: 5px; }
      .lang-item { flex: 0 0 auto; padding: 10px 14px; margin-right: 6px; }
    }
  `;

  return (
    <>
      <style>{css}</style>
      <div className={`app-layout step-${step} ${isInputFocused ? 'input-focused' : ''}`} data-theme={theme}>
        
        {notification && <div className={`toast ${notification.type}`}>{notification.text}</div>}
        
        <div className="mobile-theme-btn" style={{display: window.innerWidth > 768 ? 'none' : 'block'}} onClick={toggleTheme}>
           {theme === 'light' ? <Icons.Moon /> : <Icons.Sun />}
        </div>

        {/* SIDEBAR */}
        <div className="sidebar" style={{ width: window.innerWidth > 768 ? sidebarWidth : '100%' }}>
          <div className={`resizer-handle ${isResizing ? 'active' : ''}`} onMouseDown={startResize}></div>
          <div className="sheet-handle" onClick={() => setIsInputFocused(false)}></div>
          
          <div className="header">
            <div className="brand">ProUpload.</div>
            <button className="theme-btn" onClick={toggleTheme}>
              {theme === 'light' ? <Icons.Moon /> : <Icons.Sun />}
            </button>
          </div>

          {step === 'upload' ? (
            <>
              <input type="file" ref={fileInputRef} hidden onChange={e => handleFile(e.target.files[0])} accept="image/*" />
              
              {!selectedFile && !isCameraOpen ? (
                <div className="action-grid">
                  <div className="btn-action" onClick={() => fileInputRef.current.click()}>
                    <Icons.Folder /> <span>Файл</span>
                  </div>
                  <div className="btn-action" onClick={startCamera}>
                    <Icons.Camera /> <span>Камера</span>
                  </div>
                </div>
              ) : selectedFile ? (
                <div className="file-card">
                  <div style={{fontWeight:600, fontSize:14}}>{selectedFile.name}</div>
                  <div style={{color:'var(--text-sec)', fontSize:12}}>{(selectedFile.size/1024/1024).toFixed(2)} MB</div>
                </div>
              ) : (
                 <div className="file-card" style={{justifyContent:'center', color:'var(--primary)', borderColor:'var(--primary)'}}>
                   📷 Съемка...
                 </div>
              )}

              <div>
                <div className="label" style={{marginBottom:8, marginTop: 10}}>Язык перевода</div>
                <div className="lang-list">
                  {LANGUAGES.map(l => (
                    <div key={l.code} className={`lang-item ${language === l.code ? 'active' : ''}`} onClick={() => setLanguage(l.code)}>
                      <span style={{marginRight:8}}>{l.flag}</span> {l.label}
                      {language === l.code && window.innerWidth > 768 && <span style={{fontSize:10}}>●</span>}
                    </div>
                  ))}
                </div>
              </div>

              <button className="btn btn-primary" onClick={handleFirstUpload} disabled={!selectedFile || isLoading}>
                {isLoading ? 'Обработка...' : 'Далее'}
              </button>
            </>
          ) : (
            /* STEP 2: REVIEW */
            <>
              <div style={{display:'flex', alignItems:'center', gap:10, marginBottom:5}}>
                <button className="btn btn-secondary" onClick={() => setStep('upload')} style={{padding:8}}>
                  <Icons.Back />
                </button>
                <div style={{fontSize:16, fontWeight:700}}>Проверка</div>
              </div>
              
              <div className="form-group">
                <div className="label">Название</div>
                <input 
                    className="input-field" name="title" value={metaData.title} 
                    onChange={handleInputChange} onFocus={handleInputFocus} onBlur={handleInputBlur} 
                />
              </div>
              <div className="form-group">
                <div className="label">Автор</div>
                <input 
                    className="input-field" name="author" value={metaData.author} 
                    onChange={handleInputChange} onFocus={handleInputFocus} onBlur={handleInputBlur} 
                />
              </div>
              <div className="form-group">
                <div className="label">Год</div>
                <input 
                    className="input-field" name="year" type="number" value={metaData.year} 
                    onChange={handleInputChange} onFocus={handleInputFocus} onBlur={handleInputBlur} 
                />
              </div>

              <button className="btn btn-primary" onClick={handleFinalSubmit} disabled={isLoading} style={{marginBottom: isInputFocused ? 20 : 0}}>
                {isLoading ? 'Сохранение...' : 'Отправить'}
              </button>
            </>
          )}
        </div>

        {/* MAIN AREA */}
        <div className="main-area">
          {isCameraLoading ? (
             <div style={{color: 'var(--text-sec)', display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
                <div className="spinner" style={{
                    width: 40, height: 40, border: '4px solid var(--border)', 
                    borderTopColor: 'var(--primary)', borderRadius: '50%', 
                    animation: 'spin 1s linear infinite', marginBottom: 15
                }}></div>
                <div>Запуск камеры...</div>
                <style>{`@keyframes spin { 100% { transform: rotate(360deg); } }`}</style>
            </div>
          ) : isCameraOpen ? (
            <div className="camera-container">
              <video ref={videoRef} autoPlay playsInline muted></video>
              <div className="cam-close" onClick={stopCamera}><Icons.Close /></div>
              <div className="shutter-btn" onClick={capturePhoto}></div>
            </div>
          ) : previewUrl ? (
            <div className="preview-box">
              <div className="img-wrap">
                <img src={previewUrl} className="preview-img" style={{ transform: 'scale(1)', filter: FILTERS.find(f => f.id === activeFilter)?.style?.filter }} alt="preview" />
                {step === 'upload' && (
                  <div style={{position:'absolute', top:10, right:10, background:'rgba(0,0,0,0.6)', color:'white', borderRadius:'50%', padding:5, cursor:'pointer', zIndex:5}} 
                        onClick={() => {setSelectedFile(null); setPreviewUrl(null); setStep('upload'); setQuality(null); }}>
                    <Icons.Close />
                  </div>
                )}
                
                {/* QUALITY BADGE */}
                {quality && (
                  <div className={`quality-badge quality-${quality.status}`}>
                    {quality.status === 'good' ? <Icons.Check /> : <Icons.Warning />}
                    {quality.text}
                  </div>
                )}

              </div>
              
              <div className="tools" style={{display:'flex', gap:10, padding:5, overflowX:'auto'}}>
                 {FILTERS.map(f => (
                  <div key={f.id} className={`chip ${activeFilter === f.id ? 'active' : ''}`} onClick={() => setActiveFilter(f.id)}>
                    {f.label}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className={`drop-zone ${isDragging ? 'active' : ''}`} onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop} onClick={() => fileInputRef.current.click()}>
              <Icons.Upload />
              <div style={{marginTop:15, fontWeight:600, color:'var(--text)'}}>Перетащите фото</div>
              <div style={{fontSize:13, marginTop:5, color:'var(--text-sec)'}}>или выберите в меню</div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default PhotoUploader;
